#include <bits/stdc++.h>
#include <chrono>
#include <thread>

#define sleepMS(a) std::this_thread::sleep_for(std::chrono::milliseconds(a))

auto funa = [] { sleepMS(100); };
auto funb = [] { sleepMS(200); };

std::vector<double> timeStamp(5);
auto last = std::chrono::steady_clock::now();

inline auto timerLog(int id) {
  auto now = std::chrono::steady_clock::now();
  auto dTimeSpan = std::chrono::duration<double, std::milli>(now - last);
  timeStamp[id] += dTimeSpan.count() ;
  last = now;
}

int main() {
  timerLog(0);
  for (int i = 0; i < 10; i++) {
    funa();
    timerLog(1);
    funb();
    timerLog(2);
    funa();
    timerLog(3);
  }

  for (auto x : timeStamp) {
    std::cout<<x<<"  ms "<<std::endl;
  }
}