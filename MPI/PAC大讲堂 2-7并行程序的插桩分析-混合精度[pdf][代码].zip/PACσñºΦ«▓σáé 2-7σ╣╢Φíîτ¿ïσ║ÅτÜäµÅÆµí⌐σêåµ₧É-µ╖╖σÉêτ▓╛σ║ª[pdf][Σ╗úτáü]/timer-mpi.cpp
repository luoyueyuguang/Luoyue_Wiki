#include <bits/stdc++.h>
#include <chrono>
#include <thread>
#include <mpi.h>

int main(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);

    int id, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double duration[1];
    auto start = std::chrono::high_resolution_clock::now();
    std::this_thread::sleep_for(std::chrono::seconds(1));
    auto stop = std::chrono::high_resolution_clock::now();

    duration[0] = std::chrono::duration_cast<std::chrono::microseconds>(stop - start).count();

    if(id==0){
        double duration_list[64]={duration[0]};
        for (int i = 1; i < size; i++)
            MPI_Recv(duration_list+i ,1,MPI_DOUBLE,i,i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
        
        for (size_t i = 0; i < size; i++)
            std::cout << "[id = "<<i<< "] Elapsed time : " << duration[i] << " microseconds" << std::endl;
    }else{
        MPI_Send(duration,1,MPI_DOUBLE,0,id,MPI_COMM_WORLD);
    }
}
