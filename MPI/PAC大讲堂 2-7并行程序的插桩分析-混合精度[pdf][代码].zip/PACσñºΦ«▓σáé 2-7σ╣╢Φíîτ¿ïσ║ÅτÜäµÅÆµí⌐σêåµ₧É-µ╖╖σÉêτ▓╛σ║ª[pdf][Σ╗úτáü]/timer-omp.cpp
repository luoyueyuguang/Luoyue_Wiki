#include <bits/stdc++.h>
#include <chrono>
#include <thread>
#include <mpi.h>

int main(int argc, char* argv[]) {
double duration[64];
    #pragma omp parallel
    {
        auto id = omp_get_thread_num();
        auto start = std::chrono::high_resolution_clock::now();
        std::this_thread::sleep_for(std::chrono::seconds(1));
        auto stop = std::chrono::high_resolution_clock::now();
        duration[id] = std::chrono::duration_cast<std::chrono::microseconds>(stop - start).count();
    }
    for (size_t i = 0; i < omp_get_max_threads() ; i++)
    {
        std::cout << "[id = "<<i<< "] Elapsed time : " << duration[i] << " microseconds" << std::endl;
    }

}
